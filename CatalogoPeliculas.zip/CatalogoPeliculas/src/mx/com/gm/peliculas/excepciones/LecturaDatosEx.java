package mx.com.gm.peliculas.excepciones;

public class LecturaDatosEx extends AccesoDatosEx{
    
    public LecturaDatosEx(String mensaje){
        super(mensaje);
    }
}
